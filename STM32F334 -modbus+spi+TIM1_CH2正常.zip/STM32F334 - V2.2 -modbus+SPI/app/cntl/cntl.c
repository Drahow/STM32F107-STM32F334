#include "cntl.h"
#include "adc.h"
#include "stdlib.h"
#include "math.h"
#include "pid.h"
#include "timer.h"

extern uint32_t	PWM_PER;				//PWMʱ�Ӽ�������ֵ

void cntl_init(void)
{	
	//myADC_Init();
	
	TIMER1_PWM_Init(PWM_FREQUENCY);
	pid_func.reset(&pid_voltage_loop);
	pid_voltage_loop.T			= (float32)1.0e6/VOLTAGE_FREQUENCY;
	pid_voltage_loop.Kp			= 20;			
	pid_voltage_loop.Ti			= 800;
	pid_voltage_loop.Td			= 0.00;
	pid_voltage_loop.OutMin	= (0.01f * PWM_PER);
	pid_voltage_loop.OutMax = (0.95f * PWM_PER);
	pid_func.init(&pid_voltage_loop);
	
	pid_func.reset(&pid_current_loop);
	pid_current_loop.T			= (float32)(1.0e6/CURRENT_FREQUENCY);
	pid_current_loop.Kp			= 105;			
	pid_current_loop.Ti			= 580;
	pid_current_loop.Td			= 0.00;
	pid_current_loop.OutMin	= 0.01f * PWM_PER;
	pid_current_loop.OutMax = 0.95f * PWM_PER;
	pid_func.init(&pid_current_loop);
}
