#include "spi.h"
#include "stm32f30x_gpio.h"
#include "stm32f30x_spi.h"
#include "stm32f30x_rcc.h"
#include "modbus.h"

u8 tbuff[]="0123456789";
u8 rbuff[20];
MYSPI myspi;
extern u8 poweron;

void SPI1_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef	 SPI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_SPI1|RCC_APB2Periph_SYSCFG, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin		=	GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode	=	GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource5,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource6,GPIO_AF_5);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource7,GPIO_AF_5);
	GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7);
	
//	GPIO_InitStructure.GPIO_Pin		=	GPIO_Pin_6;
//	GPIO_InitStructure.GPIO_Mode	=	GPIO_Mode_AF;
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
//	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
//	GPIO_Init(GPIOA,&GPIO_InitStructure);
//	GPIO_SetBits(GPIOA,GPIO_Pin_6);
	
	GPIO_InitStructure.GPIO_Pin		=	GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode	=	GPIO_Mode_IN;	
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
//	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	
	SPI_InitStructure.SPI_Direction 				= SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_DataSize					=	SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL							= SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA							= SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS               = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
	SPI_InitStructure.SPI_CRCPolynomial     = 7;
	SPI_InitStructure.SPI_Mode							= SPI_Mode_Slave;
	SPI_InitStructure.SPI_FirstBit          = SPI_FirstBit_MSB;
	SPI_Init(SPI1,&SPI_InitStructure);
	
	SPI_I2S_ITConfig(SPI1,SPI_I2S_IT_RXNE,ENABLE);
	NVIC_InitStructure.NVIC_IRQChannel										=	SPI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd									= ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority  = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority         = 0;
	NVIC_Init(&NVIC_InitStructure);	
	
	SPI_Cmd(SPI1,ENABLE);
}

u8 SPI1_ReadWriteByte(u8 TxData)
{
	u16 retry = 0;
	static u8 __data;
	while(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == 0)
	{
		retry++;
		if(retry>200) return 0;
	}
	SPI_SendData8(SPI1,TxData);
	retry = 0;
	while(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE) == 0 )
	{
		retry++;
		if(retry>200) return 0;
	}
	return SPI_ReceiveData8(SPI1);
}

void SPI_32(u8 *pdata,u8 *buff,u32 len)
{
	while(len--)
	{
		*buff++ = SPI1_ReadWriteByte(*pdata++);
	}
}

void SPI1_IRQHandler(void)
{
	u8 spi_buf;
	u16 retry;
//	while(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE) == 0)
//	{
//		retry++;
//		if(retry>200) break ;
//	}	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4) == 1)
	{
		if(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE) == 1)
		{
			spi_buf = SPI_ReceiveData8(SPI1);
		}
		modbus_spi.recount = 0;
		modbus_spi.Sendcount = 0;
	}
	else
	{
		if(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_RXNE) == 1)
		{
			spi_buf = SPI_ReceiveData8(SPI1);
		//		if(modbus_spi.reflag == 1)  return ;
		
			modbus_spi.rcbuf[modbus_spi.recount++] = spi_buf;
			modbus_spi.timout = 0;
		}			
		if(modbus_spi.recount == 1) modbus_spi.timrun = 1;
		if(modbus_spi.recount == (8+1-poweron)) Modbus_SPI_Event();
	
//	while(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == 0 )
//	{
//		retry++;
//		if(retry>200) break ;
//	}	
		if(SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == 1 )
		{
			if(modbus_spi.recount > 8)
			{
				SPI_SendData8(SPI1,modbus_spi.Sendbuf[modbus_spi.Sendcount++]);
			}		
		}
		}

	SPI_I2S_ClearFlag(SPI1,SPI_I2S_FLAG_RXNE);		
}