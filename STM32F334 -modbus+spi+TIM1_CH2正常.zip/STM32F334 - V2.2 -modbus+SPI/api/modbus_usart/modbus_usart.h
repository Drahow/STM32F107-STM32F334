#ifndef __MODBUSUSART_H
#define __MODBUSUSART_H

#include "stm32f30x_conf.h"

void Usart_Init(void);
void Usart_SendByte(u8 d);

#endif
