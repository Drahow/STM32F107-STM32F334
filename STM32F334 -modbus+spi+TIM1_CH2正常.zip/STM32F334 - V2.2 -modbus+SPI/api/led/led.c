#include "led.h"
#include "stm32f30x.h"
#include "stm32f30x_gpio.h"
#include "timer.h"

void LED2A_Init(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin = LED2A_GPIO_PIN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED2A_GPIO_PORT,&GPIO_InitStructure);
}

void LED2A_Off()
{
	LED2A_GPIO_PORT->BRR = LED2A_GPIO_PIN;
}

void LED2A_On()
{
	LED2A_GPIO_PORT->BSRR = LED2A_GPIO_PIN;
}

void LED2A_Toogle()
{
	LED2A_On();
	Delay_ms(500);
	LED2A_Off();
	Delay_ms(500);
}

void LEDC_Init(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin = LEDC_GPIO_PIN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LEDC_GPIO_PORT,&GPIO_InitStructure);
}

void LEDC_On(void)
{
	LEDC_GPIO_PORT->BRR = LEDC_GPIO_PIN;
}

void LEDC_Off(void)
{
	LEDC_GPIO_PORT->BSRR = LEDC_GPIO_PIN;
}

void LEDC_Toogle(void)
{
	LEDC_On();
	Delay_ms(500);
	LEDC_Off();
	Delay_ms(500);
}
