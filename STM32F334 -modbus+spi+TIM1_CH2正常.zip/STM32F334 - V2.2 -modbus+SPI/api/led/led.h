#ifndef __LED_H
#define __LED_H
void LED2A_Init(void);

void LED2A_Toogle(void);

void LED2A_Off(void);

void LED2A_On(void);

void LEDC_Init(void);

void LEDC_Toogle(void);

void LEDC_Off(void);

void LEDC_On(void);

#define LED2A_GPIO_PORT	GPIOB
#define LED2A_GPIO_PIN	GPIO_Pin_12

#define LEDC_GPIO_PORT	GPIOC
#define LEDC_GPIO_PIN		GPIO_Pin_13

#endif
