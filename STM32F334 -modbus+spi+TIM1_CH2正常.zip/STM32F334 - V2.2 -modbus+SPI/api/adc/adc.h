#ifndef __ADC_H
#define __ADC_H

#include "stm32f30x_rcc.h"

#define PWM_FREQUENCY				110000										//PWM ����Ƶ��,��λHZ��50kHZ

#define VOLTAGE_FREQUENCY				(PWM_FREQUENCY/5)	//��ѹ������
#define CURRENT_FREQUENCY				(PWM_FREQUENCY/5) 	//����������

typedef struct
{
	float Kp;
	float Ti;
	float Td;
}PID_SET;
extern PID_SET pid_voltage_set;
extern PID_SET pid_current_set;

void myADC_Init(void);
void sample_point_gat(uint16_t* arr, uint8_t size, uint16_t value);
float average( uint16_t* arr, uint8_t len);
float sample_ADI_cal(uint8_t IN_OUT);
float sample_ADVINOUT_cal(void);
float sample_ADV42V_cal(void);
void user_init(void);

#define IN 	1
#define OUT 2

#define IS_INOUT(INOUT)	(((INOUT) == IN) || ((INOUT) == OUT))

#endif
